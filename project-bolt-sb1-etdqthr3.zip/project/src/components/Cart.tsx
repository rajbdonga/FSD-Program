import React from 'react';
import { X, Plus, Minus, ShoppingBag, Trash2 } from 'lucide-react';

interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

interface CartProps {
  showCart: boolean;
  setShowCart: (show: boolean) => void;
  cartItems: CartItem[];
  updateCartItem: (id: number, quantity: number) => void;
  removeFromCart: (id: number) => void;
  user: any;
  setShowLogin: (show: boolean) => void;
}

const Cart: React.FC<CartProps> = ({
  showCart,
  setShowCart,
  cartItems,
  updateCartItem,
  removeFromCart,
  user,
  setShowLogin
}) => {
  const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const delivery = subtotal > 25 ? 0 : 3.99; // Free delivery above $25
  const total = subtotal + tax + delivery;

  const handleCheckout = () => {
    if (!user) {
      setShowCart(false);
      setShowLogin(true);
      return;
    }
    
    // Simulate checkout process
    alert(`Order placed successfully! Total: $${total.toFixed(2)}\nThank you for choosing CafeBean!`);
    // Clear cart after successful order
    cartItems.forEach(item => removeFromCart(item.id));
    setShowCart(false);
  };

  if (!showCart) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-end z-50">
      <div className="bg-white h-full w-full max-w-md shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="h-6 w-6 text-coffee-black" />
            <h2 className="text-xl font-bold text-coffee-black font-serif">Your Cart</h2>
          </div>
          <button
            onClick={() => setShowCart(false)}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-6">
          {cartItems.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingBag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">Your cart is empty</p>
              <p className="text-gray-400 text-sm mt-2">Add some delicious items to get started!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center space-x-4 bg-bakery-cream p-4 rounded-lg">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-coffee-black">{item.name}</h3>
                    <p className="text-latte-brown font-bold">${item.price.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateCartItem(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                    >
                      <Minus className="h-4 w-4 text-gray-600" />
                    </button>
                    <span className="w-8 text-center font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => updateCartItem(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                    >
                      <Plus className="h-4 w-4 text-gray-600" />
                    </button>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-500 hover:text-red-700 transition-colors"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order Summary */}
        {cartItems.length > 0 && (
          <div className="border-t border-gray-200 p-6 bg-gray-50">
            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Tax (8%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Delivery</span>
                <span>{delivery === 0 ? 'Free' : `$${delivery.toFixed(2)}`}</span>
              </div>
              {subtotal < 25 && (
                <p className="text-xs text-gray-500">
                  Add ${(25 - subtotal).toFixed(2)} more for free delivery!
                </p>
              )}
              <div className="border-t border-gray-300 pt-2">
                <div className="flex justify-between text-lg font-bold text-coffee-black">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <button
              onClick={handleCheckout}
              className="w-full bg-coffee-black text-bakery-cream py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors duration-300"
            >
              {user ? 'Proceed to Checkout' : 'Login to Checkout'}
            </button>
            
            <button
              onClick={() => setShowCart(false)}
              className="w-full mt-2 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 transition-colors duration-300"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;