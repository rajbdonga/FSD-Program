import React, { useState, useEffect } from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen bg-bakery-cream overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-coffee-black"></div>
        <div className="absolute top-40 right-20 w-24 h-24 rounded-full bg-latte-brown"></div>
        <div className="absolute bottom-40 left-1/4 w-16 h-16 rounded-full bg-coffee-black"></div>
      </div>

      <div className="relative z-10 pt-20">
        {/* Top Section with Food Images */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Scattered Food Images */}
          <div className="relative h-96 mb-16">
            {/* Coffee Cup - Top Left */}
            <div className="absolute top-0 left-8 w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden shadow-lg transform rotate-12">
              <img
                src="https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                alt="Coffee cup"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Croissant - Top Right */}
            <div className="absolute top-8 right-12 w-28 h-20 md:w-36 md:h-24 rounded-lg overflow-hidden shadow-lg transform -rotate-12">
              <img
                src="https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Croissant"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Pastry - Center Left */}
            <div className="absolute top-20 left-1/4 w-20 h-20 md:w-28 md:h-28 rounded-full overflow-hidden shadow-lg transform rotate-45">
              <img
                src="https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                alt="Pastry"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Bread - Center Right */}
            <div className="absolute top-12 right-1/4 w-24 h-16 md:w-32 md:h-20 rounded-lg overflow-hidden shadow-lg transform -rotate-6">
              <img
                src="https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop"
                alt="Artisan bread"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Donut - Bottom Left */}
            <div className="absolute bottom-8 left-16 w-20 h-20 md:w-24 md:h-24 rounded-full overflow-hidden shadow-lg transform rotate-12">
              <img
                src="https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                alt="Donut"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Cake Slice - Bottom Right */}
            <div className="absolute bottom-4 right-8 w-24 h-20 md:w-32 md:h-24 rounded-lg overflow-hidden shadow-lg transform -rotate-12">
              <img
                src="https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Cake slice"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Muffin - Center */}
            <div className="absolute top-32 left-1/2 transform -translate-x-1/2 w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden shadow-lg rotate-6">
              <img
                src="https://images.pexels.com/photos/2067564/pexels-photo-2067564.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                alt="Muffin"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="text-center max-w-4xl mx-auto">
            <div className="mb-6">
              <p className="text-coffee-black text-sm md:text-base font-medium tracking-wider uppercase mb-4">
                Handcrafted & Made with Love Daily
              </p>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-coffee-black mb-6 font-serif leading-tight">
              Freshly Baked,
              <br />
              <span className="text-4xl md:text-6xl lg:text-7xl">Just for You!</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
              Welcome to CafeBean - where every cup tells a story and every bite is crafted with passion. 
              Experience the perfect blend of artisan coffee and freshly baked delights.
            </p>
            
            <button 
              onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-coffee-black text-bakery-cream px-8 py-4 rounded-full font-semibold text-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              ORDER NOW
            </button>
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="bg-white py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            {/* Coffee Bean Icon */}
            <div className="flex justify-center mb-8">
              <div className="w-12 h-6 bg-coffee-black rounded-full relative">
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-4 bg-bakery-cream rounded-full"></div>
              </div>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold text-coffee-black mb-6 font-serif">
              Why Choose CafeBean?
            </h2>
            
            <p className="text-gray-600 text-lg max-w-3xl mx-auto mb-16 leading-relaxed">
              At CafeBean, we combine traditional baking techniques with premium ingredients to create 
              exceptional coffee and bakery experiences that bring people together.
            </p>

            {/* Three Cards */}
            <div className="grid md:grid-cols-3 gap-8 mb-16">
              {/* Artisan Breads */}
              <div className="group">
                <div className="relative overflow-hidden rounded-2xl mb-6 h-64">
                  <img
                    src="https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
                    alt="Artisan Breads"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
                <h3 className="text-2xl font-bold text-coffee-black mb-4 font-serif">Artisan Breads</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Handcrafted daily using traditional techniques and premium ingredients for authentic flavors.
                </p>
                <button 
                  onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-coffee-black text-bakery-cream px-6 py-2 rounded-full font-medium hover:bg-opacity-90 transition-colors"
                >
                  Explore Breads
                </button>
              </div>

              {/* Sweet Pastries */}
              <div className="group">
                <div className="relative overflow-hidden rounded-2xl mb-6 h-64">
                  <img
                    src="https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
                    alt="Sweet Pastries"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
                <h3 className="text-2xl font-bold text-coffee-black mb-4 font-serif">Sweet Pastries</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Delicate pastries crafted with butter, love, and generations of baking expertise.
                </p>
                <button 
                  onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-coffee-black text-bakery-cream px-6 py-2 rounded-full font-medium hover:bg-opacity-90 transition-colors"
                >
                  Try Pastries
                </button>
              </div>

              {/* Premium Coffee */}
              <div className="group">
                <div className="relative overflow-hidden rounded-2xl mb-6 h-64">
                  <img
                    src="https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
                    alt="Premium Coffee"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
                <h3 className="text-2xl font-bold text-coffee-black mb-4 font-serif">Premium Coffee</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Single-origin beans expertly roasted and brewed to perfection for the ultimate coffee experience.
                </p>
                <button 
                  onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-coffee-black text-bakery-cream px-6 py-2 rounded-full font-medium hover:bg-opacity-90 transition-colors"
                >
                  Order Coffee
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Visit Us Today Section */}
        <div className="bg-bakery-cream py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left Content */}
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-coffee-black mb-6 font-serif italic">
                  Visit CafeBean Today
                </h2>
                <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                  Step into our warm, inviting space where the aroma of freshly brewed coffee mingles 
                  with the scent of just-baked pastries. Whether you're starting your day, meeting 
                  friends, or taking a well-deserved break, CafeBean is your perfect destination.
                </p>
                <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                  Our skilled baristas and bakers work tirelessly to ensure every cup and every bite 
                  exceeds your expectations. Come experience the CafeBean difference today.
                </p>
                <button 
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-coffee-black text-bakery-cream px-8 py-3 rounded-full font-semibold hover:bg-opacity-90 transition-colors"
                >
                  VISIT US TODAY
                </button>
              </div>

              {/* Right Images Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="aspect-square rounded-2xl overflow-hidden">
                    <img
                      src="https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                      alt="Donuts"
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/3] rounded-2xl overflow-hidden">
                    <img
                      src="https://images.pexels.com/photos/2067564/pexels-photo-2067564.jpeg?auto=compress&cs=tinysrgb&w=300&h=225&fit=crop"
                      alt="Coffee and pastries"
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="aspect-[4/3] rounded-2xl overflow-hidden">
                    <img
                      src="https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=300&h=225&fit=crop"
                      alt="Pastries"
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-square rounded-2xl overflow-hidden">
                    <img
                      src="https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                      alt="Cake slice"
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Gallery Section */}
        <div className="bg-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Left Image */}
              <div className="md:col-span-1">
                <div className="aspect-[3/4] rounded-2xl overflow-hidden mb-6">
                  <img
                    src="https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=533&fit=crop"
                    alt="Artisan breads"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
              </div>

              {/* Center Images */}
              <div className="md:col-span-1 space-y-8">
                <div className="aspect-square rounded-2xl overflow-hidden">
                  <img
                    src="https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
                    alt="Croissants"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-coffee-black mb-2 font-serif italic">Explore Baking</h3>
                  <p className="text-gray-600">
                    Discover our traditional baking methods and premium ingredients that make every bite special.
                  </p>
                </div>
              </div>

              {/* Right Image */}
              <div className="md:col-span-1">
                <div className="aspect-[3/4] rounded-2xl overflow-hidden mb-6">
                  <img
                    src="https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=400&h=533&fit=crop"
                    alt="Custom cakes"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-coffee-black mb-2 font-serif italic">Artisan Eating</h3>
                  <p className="text-gray-600">
                    Savor the authentic flavors and textures that come from time-honored baking traditions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;