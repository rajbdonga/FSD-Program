import React from 'react';
import { Coffee, Instagram, Facebook, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-coffee-black text-cream-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Coffee className="h-8 w-8 text-latte-brown" />
              <span className="text-2xl font-bold">CafeBean</span>
            </div>
            <p className="text-cream-white opacity-80 mb-6 leading-relaxed">
              Serving exceptional coffee and creating community connections since 2023. 
              Every cup is crafted with passion and precision to deliver the perfect experience.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-cream-white hover:text-latte-brown transition-colors duration-300">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-cream-white hover:text-latte-brown transition-colors duration-300">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-cream-white hover:text-latte-brown transition-colors duration-300">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="mailto:hello@cafebean.com" className="text-cream-white hover:text-latte-brown transition-colors duration-300">
                <Mail className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-latte-brown">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-cream-white opacity-80 hover:opacity-100 hover:text-latte-brown transition-colors duration-300">Home</a></li>
              <li><a href="#menu" className="text-cream-white opacity-80 hover:opacity-100 hover:text-latte-brown transition-colors duration-300">Menu</a></li>
              <li><a href="#about" className="text-cream-white opacity-80 hover:opacity-100 hover:text-latte-brown transition-colors duration-300">About Us</a></li>
              <li><a href="#contact" className="text-cream-white opacity-80 hover:opacity-100 hover:text-latte-brown transition-colors duration-300">Contact</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-latte-brown">Contact Info</h3>
            <div className="space-y-2 text-cream-white opacity-80">
              <p>123 Coffee Street</p>
              <p>Downtown District, NY 10001</p>
              <p>(555) 123-CAFE</p>
              <p>hello@cafebean.com</p>
            </div>
            <div className="mt-4">
              <h4 className="text-sm font-semibold mb-2 text-latte-brown">Hours</h4>
              <div className="text-sm text-cream-white opacity-80">
                <p>Mon-Fri: 6AM - 8PM</p>
                <p>Sat-Sun: 7AM - 9PM</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-cream-white opacity-60">
            © 2025 CafeBean. All rights reserved. | Crafted with ❤️ for coffee lovers
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;