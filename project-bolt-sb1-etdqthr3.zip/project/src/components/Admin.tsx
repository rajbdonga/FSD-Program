import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Calendar, Users } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isVegan: boolean;
  isGlutenFree: boolean;
  isFeatured: boolean;
}

interface Reservation {
  id: number;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  message: string;
  status: 'pending' | 'confirmed' | 'cancelled';
}

const Admin: React.FC = () => {
  const [activeTab, setActiveTab] = useState('menu');
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const tabs = [
    { id: 'menu', label: 'Menu Management', icon: '📋' },
    { id: 'reservations', label: 'Reservations', icon: '📅' }
  ];

  useEffect(() => {
    // Mock data
    const mockItems: MenuItem[] = [
      {
        id: 1,
        name: 'Signature Latte',
        description: 'Our house blend with steamed milk and a touch of vanilla',
        price: 4.50,
        image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
        category: 'coffee',
        isVegan: false,
        isGlutenFree: true,
        isFeatured: true
      },
      {
        id: 2,
        name: 'Cold Brew',
        description: 'Smooth, rich cold-brewed coffee served over ice',
        price: 3.75,
        image: 'https://images.pexels.com/photos/1281912/pexels-photo-1281912.jpeg',
        category: 'coffee',
        isVegan: true,
        isGlutenFree: true,
        isFeatured: false
      }
    ];

    const mockReservations: Reservation[] = [
      {
        id: 1,
        name: 'John Smith',
        email: 'john@example.com',
        phone: '(555) 123-4567',
        date: '2025-01-20',
        time: '14:00',
        guests: 2,
        message: 'Anniversary dinner',
        status: 'pending'
      },
      {
        id: 2,
        name: 'Sarah Johnson',
        email: 'sarah@example.com',
        phone: '(555) 987-6543',
        date: '2025-01-21',
        time: '18:30',
        guests: 4,
        message: 'Business meeting',
        status: 'confirmed'
      }
    ];

    setMenuItems(mockItems);
    setReservations(mockReservations);
  }, []);

  const handleSaveItem = (item: MenuItem) => {
    if (item.id === 0) {
      // Add new item
      const newItem = { ...item, id: Date.now() };
      setMenuItems([...menuItems, newItem]);
    } else {
      // Update existing item
      setMenuItems(menuItems.map(i => i.id === item.id ? item : i));
    }
    setEditingItem(null);
    setShowAddForm(false);
  };

  const handleDeleteItem = (id: number) => {
    if (confirm('Are you sure you want to delete this item?')) {
      setMenuItems(menuItems.filter(item => item.id !== id));
    }
  };

  const handleReservationStatusChange = (id: number, status: 'pending' | 'confirmed' | 'cancelled') => {
    setReservations(reservations.map(res => 
      res.id === id ? { ...res, status } : res
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-coffee-black font-serif">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your cafe's menu and reservations</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-4 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                activeTab === tab.id
                  ? 'bg-latte-brown text-coffee-black'
                  : 'bg-white text-gray-600 hover:bg-latte-brown hover:text-coffee-black'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Menu Management */}
        {activeTab === 'menu' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-coffee-black">Menu Items</h2>
              <button
                onClick={() => setShowAddForm(true)}
                className="bg-latte-brown text-coffee-black px-4 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-colors flex items-center space-x-2"
              >
                <Plus className="h-5 w-5" />
                <span>Add Item</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuItems.map((item) => (
                <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-32 object-cover"
                  />
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-coffee-black">{item.name}</h3>
                      <span className="text-latte-brown font-bold">${item.price}</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                        {item.category}
                      </span>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setEditingItem(item)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(item.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reservations */}
        {activeTab === 'reservations' && (
          <div>
            <h2 className="text-2xl font-bold text-coffee-black mb-6">Reservations</h2>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date & Time
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Guests
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {reservations.map((reservation) => (
                      <tr key={reservation.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{reservation.name}</div>
                            <div className="text-sm text-gray-500">{reservation.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{reservation.date}</div>
                          <div className="text-sm text-gray-500">{reservation.time}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {reservation.guests}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(reservation.status)}`}>
                            {reservation.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <select
                            value={reservation.status}
                            onChange={(e) => handleReservationStatusChange(reservation.id, e.target.value as any)}
                            className="border border-gray-300 rounded px-2 py-1 text-xs"
                          >
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Edit/Add Item Modal */}
        {(editingItem || showAddForm) && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md m-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">
                  {editingItem ? 'Edit Item' : 'Add New Item'}
                </h3>
                <button
                  onClick={() => {
                    setEditingItem(null);
                    setShowAddForm(false);
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  const item: MenuItem = {
                    id: editingItem?.id || 0,
                    name: formData.get('name') as string,
                    description: formData.get('description') as string,
                    price: parseFloat(formData.get('price') as string),
                    image: formData.get('image') as string,
                    category: formData.get('category') as string,
                    isVegan: formData.has('isVegan'),
                    isGlutenFree: formData.has('isGlutenFree'),
                    isFeatured: formData.has('isFeatured')
                  };
                  handleSaveItem(item);
                }}
                className="space-y-4"
              >
                <input
                  name="name"
                  placeholder="Item name"
                  defaultValue={editingItem?.name}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
                <textarea
                  name="description"
                  placeholder="Description"
                  defaultValue={editingItem?.description}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
                <input
                  name="price"
                  type="number"
                  step="0.01"
                  placeholder="Price"
                  defaultValue={editingItem?.price}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
                <input
                  name="image"
                  placeholder="Image URL"
                  defaultValue={editingItem?.image}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
                <select
                  name="category"
                  defaultValue={editingItem?.category}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="coffee">Coffee</option>
                  <option value="tea">Tea</option>
                  <option value="food">Food</option>
                  <option value="desserts">Desserts</option>
                </select>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      name="isVegan"
                      defaultChecked={editingItem?.isVegan}
                    />
                    <span>Vegan</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      name="isGlutenFree"
                      defaultChecked={editingItem?.isGlutenFree}
                    />
                    <span>Gluten Free</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      name="isFeatured"
                      defaultChecked={editingItem?.isFeatured}
                    />
                    <span>Featured</span>
                  </label>
                </div>
                <div className="flex space-x-3">
                  <button
                    type="submit"
                    className="flex-1 bg-latte-brown text-coffee-black py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Save className="h-4 w-4" />
                    <span>Save</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingItem(null);
                      setShowAddForm(false);
                    }}
                    className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;