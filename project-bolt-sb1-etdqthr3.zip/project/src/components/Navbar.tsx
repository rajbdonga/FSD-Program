import React, { useState } from 'react';
import { Menu, X, ShoppingCart, User, LogOut } from 'lucide-react';

interface NavbarProps {
  user: any;
  setUser: (user: any) => void;
  cartItems: any[];
  setShowCart: (show: boolean) => void;
  setShowLogin: (show: boolean) => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, setUser, cartItems, setShowCart, setShowLogin }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { href: '#home', label: 'HOME' },
    { href: '#menu', label: 'MENU' },
    { href: '#about', label: 'ABOUT' },
    { href: '#contact', label: 'CONTACT US' },
  ];

  const handleOrderNow = () => {
    if (!user) {
      setShowLogin(true);
    } else {
      document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 right-0 bg-bakery-cream bg-opacity-95 backdrop-blur-sm z-50 shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar */}
        <div className="hidden md:flex items-center justify-between py-2 text-sm border-b border-gray-200">
          <div className="flex items-center space-x-6 text-gray-600">
            <span>Fresh Coffee & Pastries Daily</span>
            <span>•</span>
            <span>Order Online 24/7</span>
            <span>•</span>
            <span>Free Delivery Above $25</span>
          </div>
          <div className="flex items-center space-x-4 text-gray-600">
            <span>📞 (555) 123-CAFE</span>
            <span>📧 hello@cafebean.com</span>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-coffee-black font-serif">
                CAFEBEAN
              </div>
              <div className="text-xs text-gray-500 tracking-wider">
                ARTISAN CAFE
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-coffee-black hover:text-latte-brown transition-colors duration-300 text-sm font-medium tracking-wide"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <div className="flex items-center space-x-2 text-coffee-black">
                  <User className="h-4 w-4" />
                  <span className="text-sm">Hi, {user.name}</span>
                </div>
                <button
                  onClick={() => setShowCart(true)}
                  className="relative text-coffee-black hover:text-latte-brown transition-colors duration-300"
                >
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-berry-red text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {cartItemCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={handleLogout}
                  className="text-coffee-black hover:text-latte-brown transition-colors duration-300 flex items-center space-x-1"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="text-sm">Logout</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => setShowLogin(true)}
                className="text-coffee-black hover:text-latte-brown transition-colors duration-300 flex items-center space-x-1"
              >
                <User className="h-4 w-4" />
                <span className="text-sm">Login</span>
              </button>
            )}
            <button
              onClick={handleOrderNow}
              className="bg-coffee-black text-bakery-cream px-6 py-2 rounded-full font-semibold text-sm hover:bg-opacity-90 transition-colors duration-300"
            >
              ORDER NOW
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            {user && (
              <button
                onClick={() => setShowCart(true)}
                className="relative text-coffee-black hover:text-latte-brown transition-colors duration-300"
              >
                <ShoppingCart className="h-5 w-5" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-berry-red text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </button>
            )}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-coffee-black hover:text-latte-brown transition-colors duration-300"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-bakery-cream border-t border-gray-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-coffee-black hover:text-latte-brown block px-3 py-2 text-base font-medium transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </a>
            ))}
            {user ? (
              <>
                <div className="px-3 py-2 text-coffee-black">
                  Hi, {user.name}
                </div>
                <button
                  onClick={() => {
                    handleLogout();
                    setIsOpen(false);
                  }}
                  className="text-coffee-black hover:text-latte-brown block px-3 py-2 text-base font-medium transition-colors duration-300"
                >
                  Logout
                </button>
              </>
            ) : (
              <button
                onClick={() => {
                  setShowLogin(true);
                  setIsOpen(false);
                }}
                className="text-coffee-black hover:text-latte-brown block px-3 py-2 text-base font-medium transition-colors duration-300"
              >
                Login
              </button>
            )}
            <div className="px-3 py-2">
              <button
                onClick={() => {
                  handleOrderNow();
                  setIsOpen(false);
                }}
                className="w-full bg-coffee-black text-bakery-cream px-6 py-2 rounded-full font-semibold text-sm hover:bg-opacity-90 transition-colors duration-300"
              >
                ORDER NOW
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;