import React from 'react';
import { Award, Coffee, Users, Heart } from 'lucide-react';

const About: React.FC = () => {
  const timeline = [
    { year: '2023', event: 'Artisan Cafe opens its doors with a passion for quality coffee' },
    { year: '2024', event: 'Expanded to include artisanal pastries and light meals' },
    { year: '2024', event: 'Introduced sustainable sourcing and eco-friendly practices' },
    { year: '2025', event: 'Growing community hub for coffee enthusiasts' }
  ];

  const team = [
    {
      name: 'Sarah Chen',
      role: 'Head Barista',
      image: 'https://images.pexels.com/photos/3785077/pexels-photo-3785077.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      bio: 'Coffee enthusiast with 8 years of experience in specialty coffee'
    },
    {
      name: 'Marcus Johnson',
      role: 'Pastry Chef',
      image: 'https://images.pexels.com/photos/3748221/pexels-photo-3748221.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      bio: 'Award-winning pastry chef bringing French techniques to our cafe'
    },
    {
      name: 'Elena Rodriguez',
      role: 'Owner & Founder',
      image: 'https://images.pexels.com/photos/3767673/pexels-photo-3767673.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      bio: 'Passionate about creating community spaces through exceptional coffee'
    }
  ];

  const stats = [
    { icon: Coffee, number: '1000+', label: 'Cups Served Daily' },
    { icon: Users, number: '500+', label: 'Happy Customers' },
    { icon: Award, number: '5', label: 'Awards Won' },
    { icon: Heart, number: '100%', label: 'Made with Love' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-coffee-black mb-4 font-serif">
            About Our Story
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Born from a passion for exceptional coffee and community connection, Artisan Cafe has been serving 
            premium coffee experiences since 2023.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-4">
                <div className="bg-latte-brown p-4 rounded-full">
                  <stat.icon className="h-8 w-8 text-coffee-black" />
                </div>
              </div>
              <div className="text-3xl font-bold text-coffee-black mb-2">{stat.number}</div>
              <div className="text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Main Content */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h3 className="text-3xl font-bold text-coffee-black mb-6 font-serif">
              Crafting Perfect Moments
            </h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              At Artisan Cafe, we believe that every cup tells a story. Our journey began with a simple mission: 
              to create a space where exceptional coffee meets genuine community connection.
            </p>
            <p className="text-gray-600 mb-6 leading-relaxed">
              We source our beans directly from sustainable farms, ensuring fair trade practices while 
              delivering the highest quality to your cup. Every morning, our skilled baristas craft each 
              drink with precision and passion.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Whether you're here for your morning ritual, a business meeting, or simply to unwind with 
              friends, we've created an atmosphere that feels like home.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/2067564/pexels-photo-2067564.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop"
              alt="Coffee brewing process"
              className="rounded-xl shadow-lg w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-coffee-black/20 to-transparent rounded-xl"></div>
          </div>
        </div>

        {/* Timeline */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-coffee-black mb-12 text-center font-serif">
            Our Journey
          </h3>
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-latte-brown"></div>
            {timeline.map((item, index) => (
              <div key={index} className={`flex items-center mb-8 ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                  <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100">
                    <div className="text-2xl font-bold text-latte-brown mb-2">{item.year}</div>
                    <div className="text-gray-600">{item.event}</div>
                  </div>
                </div>
                <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-latte-brown rounded-full border-4 border-white shadow"></div>
              </div>
            ))}
          </div>
        </div>

        {/* Team Section */}
        <div>
          <h3 className="text-3xl font-bold text-coffee-black mb-12 text-center font-serif">
            Meet Our Team
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg group-hover:shadow-xl transition-shadow duration-300"
                  />
                  <div className="absolute inset-0 bg-latte-brown opacity-0 group-hover:opacity-20 rounded-full transition-opacity duration-300"></div>
                </div>
                <h4 className="text-xl font-bold text-coffee-black mb-2">{member.name}</h4>
                <p className="text-latte-brown font-semibold mb-3">{member.role}</p>
                <p className="text-gray-600 text-sm leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;