import React, { useState, useEffect } from 'react';
import { Leaf, Heart, Plus, ShoppingCart } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isVegan: boolean;
  isGlutenFree: boolean;
  isFeatured: boolean;
}

interface MenuProps {
  user: any;
  setShowLogin: (show: boolean) => void;
  addToCart: (item: MenuItem) => void;
}

const Menu: React.FC<MenuProps> = ({ user, setShowLogin, addToCart }) => {
  const [activeTab, setActiveTab] = useState('coffee');
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);

  const tabs = [
    { id: 'coffee', label: 'Coffee', icon: '☕' },
    { id: 'pastries', label: 'Pastries', icon: '🥐' },
    { id: 'breads', label: 'Breads', icon: '🍞' },
    { id: 'cakes', label: 'Cakes', icon: '🎂' }
  ];

  useEffect(() => {
    // Mock data with bakery items
    const mockItems: MenuItem[] = [
      {
        id: 1,
        name: 'Artisan Espresso',
        description: 'Rich, bold espresso crafted from premium single-origin beans',
        price: 3.50,
        image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'coffee',
        isVegan: true,
        isGlutenFree: true,
        isFeatured: true
      },
      {
        id: 2,
        name: 'Signature Latte',
        description: 'Smooth espresso with steamed milk and artisan foam art',
        price: 4.75,
        image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'coffee',
        isVegan: false,
        isGlutenFree: true,
        isFeatured: false
      },
      {
        id: 3,
        name: 'Cappuccino',
        description: 'Perfect balance of espresso, steamed milk, and foam',
        price: 4.25,
        image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'coffee',
        isVegan: false,
        isGlutenFree: true,
        isFeatured: false
      },
      {
        id: 4,
        name: 'Cold Brew',
        description: 'Smooth, refreshing cold-brewed coffee served over ice',
        price: 3.75,
        image: 'https://images.pexels.com/photos/1281912/pexels-photo-1281912.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'coffee',
        isVegan: true,
        isGlutenFree: true,
        isFeatured: false
      },
      {
        id: 5,
        name: 'Butter Croissant',
        description: 'Flaky, buttery pastry baked fresh daily with French technique',
        price: 3.25,
        image: 'https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'pastries',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: true
      },
      {
        id: 6,
        name: 'Almond Danish',
        description: 'Sweet pastry filled with almond cream and topped with sliced almonds',
        price: 4.50,
        image: 'https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'pastries',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 7,
        name: 'Chocolate Croissant',
        description: 'Buttery croissant filled with rich dark chocolate',
        price: 3.75,
        image: 'https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'pastries',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 8,
        name: 'Blueberry Muffin',
        description: 'Fluffy muffin bursting with fresh blueberries',
        price: 2.95,
        image: 'https://images.pexels.com/photos/2067564/pexels-photo-2067564.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'pastries',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 9,
        name: 'Sourdough Loaf',
        description: 'Traditional sourdough bread with crispy crust and tangy flavor',
        price: 6.00,
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'breads',
        isVegan: true,
        isGlutenFree: false,
        isFeatured: true
      },
      {
        id: 10,
        name: 'Multigrain Bread',
        description: 'Hearty bread packed with seeds, grains, and wholesome nutrition',
        price: 5.50,
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'breads',
        isVegan: true,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 11,
        name: 'French Baguette',
        description: 'Classic French baguette with golden crust and airy interior',
        price: 4.25,
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'breads',
        isVegan: true,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 12,
        name: 'Whole Wheat Bread',
        description: 'Nutritious whole wheat bread perfect for sandwiches',
        price: 4.75,
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'breads',
        isVegan: true,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 13,
        name: 'Chocolate Layer Cake',
        description: 'Decadent chocolate cake with rich ganache and fresh berries',
        price: 8.50,
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'cakes',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: true
      },
      {
        id: 14,
        name: 'Red Velvet Cupcake',
        description: 'Classic red velvet with cream cheese frosting and elegant decoration',
        price: 4.25,
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'cakes',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 15,
        name: 'Cheesecake Slice',
        description: 'Creamy New York style cheesecake with berry compote',
        price: 5.95,
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'cakes',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      },
      {
        id: 16,
        name: 'Tiramisu',
        description: 'Italian classic with coffee-soaked ladyfingers and mascarpone',
        price: 6.50,
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
        category: 'cakes',
        isVegan: false,
        isGlutenFree: false,
        isFeatured: false
      }
    ];
    setMenuItems(mockItems);
  }, []);

  const filteredItems = menuItems.filter(item => item.category === activeTab);

  const handleAddToCart = (item: MenuItem) => {
    if (!user) {
      setShowLogin(true);
      return;
    }
    addToCart(item);
  };

  return (
    <section id="menu" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-coffee-black mb-4 font-serif">
            Our Fresh Menu
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Handcrafted daily with premium ingredients and traditional techniques
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-12">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`mx-2 mb-4 px-8 py-3 rounded-full font-semibold transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-coffee-black text-bakery-cream shadow-lg transform scale-105'
                  : 'bg-bakery-cream text-coffee-black hover:bg-coffee-black hover:text-bakery-cream shadow-md border border-gray-200'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-bakery-cream rounded-2xl shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
            >
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                />
                {item.isFeatured && (
                  <div className="absolute top-4 left-4 bg-berry-red text-white px-3 py-1 rounded-full text-sm font-semibold">
                    Featured
                  </div>
                )}
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-bold text-coffee-black font-serif">
                    {item.name}
                  </h3>
                  <span className="text-lg font-bold text-coffee-black">
                    ${item.price.toFixed(2)}
                  </span>
                </div>
                <p className="text-gray-600 mb-4 leading-relaxed text-sm">
                  {item.description}
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    {item.isVegan && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-matcha-green text-white">
                        <Leaf className="w-3 h-3 mr-1" />
                        Vegan
                      </span>
                    )}
                    {item.isGlutenFree && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <Heart className="w-3 h-3 mr-1" />
                        GF
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleAddToCart(item)}
                    className="bg-coffee-black text-bakery-cream px-4 py-2 rounded-full text-sm font-medium hover:bg-opacity-90 transition-colors flex items-center space-x-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p className="text-gray-600 mb-4">Can't find what you're looking for?</p>
          <button className="bg-coffee-black text-bakery-cream px-8 py-4 rounded-full font-semibold text-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg">
            VIEW FULL MENU
          </button>
        </div>
      </div>
    </section>
  );
};

export default Menu;