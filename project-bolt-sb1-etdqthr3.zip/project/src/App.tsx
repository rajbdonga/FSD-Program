import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Menu from './components/Menu';
import About from './components/About';
import Contact from './components/Contact';
import Login from './components/Login';
import Cart from './components/Cart';
import Footer from './components/Footer';

interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

function App() {
  const [user, setUser] = useState<any>(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Load user from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }

    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (item: any) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(cartItem => cartItem.id === item.id);
      
      if (existingItem) {
        return prevItems.map(cartItem =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        return [...prevItems, { ...item, quantity: 1 }];
      }
    });

    // Show success message
    const itemName = item.name.length > 20 ? item.name.substring(0, 20) + '...' : item.name;
    alert(`${itemName} added to cart!`);
  };

  const updateCartItem = (id: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id);
      return;
    }

    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-bakery-cream">
      <Navbar 
        user={user} 
        setUser={setUser} 
        cartItems={cartItems}
        setShowCart={setShowCart}
        setShowLogin={setShowLogin}
      />
      
      <Hero />
      <Menu 
        user={user} 
        setShowLogin={setShowLogin} 
        addToCart={addToCart}
      />
      <About />
      <Contact />
      
      <Footer />

      <Login 
        showLogin={showLogin} 
        setShowLogin={setShowLogin} 
        setUser={setUser} 
      />

      <Cart
        showCart={showCart}
        setShowCart={setShowCart}
        cartItems={cartItems}
        updateCartItem={updateCartItem}
        removeFromCart={removeFromCart}
        user={user}
        setShowLogin={setShowLogin}
      />
    </div>
  );
}

export default App;