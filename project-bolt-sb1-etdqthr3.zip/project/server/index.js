const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Mock data
let menuItems = [
  {
    id: 1,
    name: 'Signature Latte',
    description: 'Our house blend with steamed milk and a touch of vanilla',
    price: 4.50,
    image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    category: 'coffee',
    isVegan: false,
    isGlutenFree: true,
    isFeatured: true
  },
  {
    id: 2,
    name: 'Cold Brew',
    description: 'Smooth, rich cold-brewed coffee served over ice',
    price: 3.75,
    image: 'https://images.pexels.com/photos/1281912/pexels-photo-1281912.jpeg',
    category: 'coffee',
    isVegan: true,
    isGlutenFree: true,
    isFeatured: false
  }
];

let reservations = [
  {
    id: 1,
    name: 'John Smith',
    email: 'john@example.com',
    phone: '(555) 123-4567',
    date: '2025-01-20',
    time: '14:00',
    guests: 2,
    message: 'Anniversary dinner',
    status: 'pending'
  }
];

// Menu Routes
app.get('/api/menu', (req, res) => {
  res.json(menuItems);
});

app.post('/api/menu', (req, res) => {
  const newItem = {
    id: Date.now(),
    ...req.body
  };
  menuItems.push(newItem);
  res.status(201).json(newItem);
});

app.put('/api/menu/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = menuItems.findIndex(item => item.id === id);
  
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }
  
  menuItems[index] = { ...menuItems[index], ...req.body };
  res.json(menuItems[index]);
});

app.delete('/api/menu/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = menuItems.findIndex(item => item.id === id);
  
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }
  
  menuItems.splice(index, 1);
  res.status(204).send();
});

// Reservation Routes
app.get('/api/reservations', (req, res) => {
  res.json(reservations);
});

app.post('/api/reservations', (req, res) => {
  const newReservation = {
    id: Date.now(),
    ...req.body,
    status: 'pending'
  };
  reservations.push(newReservation);
  res.status(201).json(newReservation);
});

app.put('/api/reservations/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = reservations.findIndex(res => res.id === id);
  
  if (index === -1) {
    return res.status(404).json({ error: 'Reservation not found' });
  }
  
  reservations[index] = { ...reservations[index], ...req.body };
  res.json(reservations[index]);
});

// Authentication (basic)
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  
  // Simple auth for demo purposes
  if (username === 'admin' && password === 'cafe123') {
    res.json({ 
      success: true, 
      token: 'demo-token',
      user: { username: 'admin', role: 'admin' }
    });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});